const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Import Litecoin wallet system
const ltcWallet = require('./litecoin-casino-bot.js');

// Create Discord client
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// Commands collection
client.commands = new Collection();

// Load commands
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
            console.log(`✅ Commande chargée: ${command.data.name}`);
        } else {
            console.log(`⚠️  Commande ${file} manque des propriétés requises`);
        }
    }
}

// Load events
const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    
    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args));
        } else {
            client.on(event.name, (...args) => event.execute(...args));
        }
        console.log(`✅ Événement chargé: ${event.name}`);
    }
}


// Interaction handling
client.on(Events.InteractionCreate, async interaction => {
    // Handle slash commands
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        
        if (!command) {
            console.error(`❌ Aucune commande correspondant à ${interaction.commandName} trouvée.`);
            return;
        }
        
        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(`❌ Erreur lors de l'exécution de ${interaction.commandName}:`, error);
            
            // Don't respond if interaction is expired or already handled
            if (error.code === 10062 || error.code === 40060) {
                console.log(`⚠️ Interaction expirée ou déjà traitée pour ${interaction.commandName}`);
                return;
            }
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Error')
                .setDescription('There was an error while executing this command!')
                .setTimestamp();
            
            try {
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
                } else {
                    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }
            } catch (replyError) {
                console.error(`❌ Erreur réponse ${interaction.commandName}:`, replyError.message);
            }
        }
    }
    
    // Handle button interactions
    if (interaction.isButton()) {
        console.log(`🔘 Button interaction: ${interaction.customId}`);
        try {
            // Add Balance button
            if (interaction.customId === 'add_balance') {
                await handleAddBalance(interaction);
            }
            // Create channel button
            else if (interaction.customId === 'create_channel') {
                await handleCreateChannel(interaction);
            }
            // Re-add balance button
            else if (interaction.customId === 'readd_balance') {
                await handleAddBalance(interaction);
            }
            // Close channel button
            else if (interaction.customId === 'close_channel') {
                await handleCloseChannel(interaction);
            }
            // Blackjack game buttons
            else if (interaction.customId.startsWith('blackjack_')) {
                await handleBlackjackInteraction(interaction);
            }
            // Roulette game buttons
            else if (interaction.customId.startsWith('roulette_')) {
                await handleRouletteInteraction(interaction);
            }
            // Casino game quick start buttons
            else if (interaction.customId === 'casino_blackjack') {
                console.log('🃏 Casino blackjack button clicked');
                await handleCasinoBlackjack(interaction);
            }
            else if (interaction.customId === 'casino_roulette') {
                console.log('🎰 Casino roulette button clicked');
                await handleCasinoRoulette(interaction);
            }
            else if (interaction.customId === 'casino_coinflip') {
                console.log('🪙 Casino coinflip button clicked');
                await handleCasinoCoinflip(interaction);
            }
            // New premium casino buttons
            else if (interaction.customId === 'create_private_session') {
                await handleCreatePrivateSession(interaction);
            }
            else if (interaction.customId === 'quick_game') {
                await handleQuickGame(interaction);
            }
            else if (interaction.customId === 'tournaments') {
                await handleTournaments(interaction);
            }
            else if (interaction.customId === 'casino_help') {
                await handleCasinoHelp(interaction);
            }
            // Session management buttons
            else if (interaction.customId.startsWith('session_')) {
                await handleSessionInteraction(interaction);
            }
            // Game action buttons
            else if (interaction.customId.startsWith('game_again_')) {
                await handleGameAgain(interaction);
            }
            else if (interaction.customId.startsWith('coinflip_again_')) {
                await handleCoinflipAgain(interaction);
            }
            else if (interaction.customId.startsWith('coinflip_quick_')) {
                await handleQuickCoinflip(interaction);
            }
            else if (interaction.customId === 'quick_cashout') {
                await handleQuickCashout(interaction);
            }
            // Channel management buttons
            else if (interaction.customId.startsWith('generate_address_')) {
                await handleGenerateAddress(interaction);
            }
            else if (interaction.customId.startsWith('cancel_deposit_')) {
                await handleCancelDeposit(interaction);
            }
            else if (interaction.customId.startsWith('confirm_cancel_')) {
                await handleConfirmCancel(interaction);
            }
            else if (interaction.customId.startsWith('keep_channel_')) {
                await handleKeepChannel(interaction);
            }
            else if (interaction.customId.startsWith('copy_address_')) {
                await handleCopyAddress(interaction);
            }
            // Other button handlers can be added here
            else {
                console.log(`❓ Interaction bouton inconnue: ${interaction.customId}`);
            }
        } catch (error) {
            console.error('❌ Erreur d\'interaction bouton:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Error')
                .setDescription('There was an error processing your request!')
                .setTimestamp();
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    }
    
    // Handle select menu interactions
    if (interaction.isStringSelectMenu()) {
        try {
            // Roulette number selection
            if (interaction.customId === 'roulette_bet_number') {
                await handleRouletteNumberBet(interaction);
            }
        } catch (error) {
            console.error('❌ Erreur d\'interaction menu:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Error')
                .setDescription('There was an error processing your selection!')
                .setTimestamp();
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    }
});

// Add Balance handler
async function handleAddBalance(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    try {
        const channelManager = require('./utils/channelManager.js');
        const { PermissionFlagsBits } = require('discord.js');
        
        // Generate new channel name with numbering
        const channelName = channelManager.getNextBalanceChannelName();
        
        // Create private channel for deposit
        const channel = await interaction.guild.channels.create({
            name: channelName,
            type: 0, // Text channel
            topic: `💰 Deposit Channel | User: ${interaction.user.username}`,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionFlagsBits.ViewChannel]
                },
                {
                    id: interaction.user.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory
                    ]
                }
            ]
        });

        // Register channel
        channelManager.registerChannel(channel.id, interaction.user.id, 'balance');
        
        // Generate new LTC address
        const newAddress = ltcWallet.generateAddress();
        if (!newAddress) {
            throw new Error('Failed to generate Litecoin address');
        }
        
        // Link address to user and add to active deposits monitoring
        const userProfiles = require('./utils/userProfiles.js');
        const securityManager = require('./utils/securityManager.js');
        const logManager = require('./utils/logManager.js');
        
        await userProfiles.linkAddressToUser(interaction.user.id, newAddress.address);
        securityManager.addActiveDeposit(interaction.user.id, newAddress.address, 0);
        
        // Log address generation
        await logManager.sendBalanceLog(client, interaction.guild.id, {
            type: 'address_generated',
            user: interaction.user,
            address: newAddress.address
        });
        
        // Start smart monitoring for this deposit
        startSmartMonitoring();
        
        // Send welcome message in private channel
        const welcomeEmbed = new EmbedBuilder()
            .setColor('#2ecc71')
            .setTitle('💰 Deposit Money - Private Channel')
            .setDescription(`Welcome ${interaction.user}! This is your private deposit channel.`)
            .addFields(
                {
                    name: '🚀 Quick Steps',
                    value: '• Click "Generate Deposit Address" below\n• Send Litecoin to the provided address\n• Wait for confirmation\n• Your balance will be automatically added!',
                    inline: false
                },
                {
                    name: '⏰ Auto-Close',
                    value: 'This channel will auto-close in 20 minutes if unused.',
                    inline: true
                },
                {
                    name: '🔒 Privacy',
                    value: 'Only you can see this channel.',
                    inline: true
                }
            )
            .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();

        const controlRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`generate_address_${channel.id}`)
                    .setLabel('📍 Generate Deposit Address')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('📍'),
                new ButtonBuilder()
                    .setCustomId(`cancel_deposit_${channel.id}`)
                    .setLabel('❌ Cancel')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('❌')
            );

        await channel.send({
            embeds: [welcomeEmbed],
            components: [controlRow]
        });

        // Reply with link to private channel
        const responseEmbed = new EmbedBuilder()
            .setColor('#3498db')
            .setTitle('✅ Private Deposit Channel Created')
            .setDescription(`Your private deposit channel has been created: ${channel}`)
            .addFields({
                name: '🎯 Next Steps',
                value: 'Click the link above to access your private deposit channel.',
                inline: false
            })
            .setTimestamp();

        await interaction.editReply({ embeds: [responseEmbed] });
        
        // Auto-close channel after 20 minutes
        setTimeout(async () => {
            try {
                const ch = interaction.guild.channels.cache.get(channel.id);
                if (ch) {
                    channelManager.unregisterChannel(channel.id);
                    await ch.delete('Auto-close: 20 minutes timeout');
                    console.log(`🗑️ Channel ${channelName} auto-fermé après 20 minutes`);
                }
            } catch (error) {
                console.error('Erreur auto-fermeture channel:', error);
            }
        }, 20 * 60 * 1000); // 20 minutes

        console.log(`💰 Channel privé créé: ${channelName} pour ${interaction.user.username}`);

    } catch (error) {
        console.error('Erreur création channel dépôt:', error);
        
        const errorEmbed = new EmbedBuilder()
            .setColor('#e74c3c')
            .setTitle('❌ Error')
            .setDescription('Failed to create deposit channel. Please try again.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

// Create Channel handler
async function handleCreateChannel(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    try {
        const guild = interaction.guild;
        const user = interaction.user;
        
        // Check if user already has a channel
        const existingChannel = guild.channels.cache.find(channel => 
            channel.name === `casino-${user.username.toLowerCase()}` && 
            channel.type === 0 // Text channel
        );
        
        if (existingChannel) {
            const alreadyExistsEmbed = new EmbedBuilder()
                .setColor('#ffaa00')
                .setTitle('⚠️ Channel Already Exists')
                .setDescription(`You already have a private channel: ${existingChannel}`)
                .setTimestamp();
            
            await interaction.editReply({ embeds: [alreadyExistsEmbed] });
            return;
        }
        
        // Create private channel
        const channel = await guild.channels.create({
            name: `casino-${user.username.toLowerCase()}`,
            type: 0, // Text channel
            topic: `Private casino session for ${user.username}`,
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: ['ViewChannel', 'SendMessages']
                },
                {
                    id: user.id,
                    allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
                }
                // Add staff role permissions here if needed
                // {
                //     id: 'STAFF_ROLE_ID',
                //     allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
                // }
            ]
        });
        
        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Private Channel Created')
            .setDescription(`Your private casino channel has been created: ${channel}`)
            .addFields(
                { name: '🎰 Features Available', value: '• Check balance\n• Play casino games\n• Withdraw funds\n• Get support', inline: false },
                { name: '⏰ Auto-Delete', value: 'Channel will be deleted after 24 hours of inactivity', inline: false }
            )
            .setTimestamp();
        
        await interaction.editReply({ embeds: [successEmbed] });
        
        // Send welcome message in the new channel
        const welcomeEmbed = new EmbedBuilder()
            .setColor('#f7931a')
            .setTitle('🎰 Welcome to Your Private Casino!')
            .setDescription(`Hello ${user}! This is your private casino session.`)
            .addFields(
                { name: '💰 Available Commands', value: '• `/profile` - View your profile\n• `/balance` - Check balance\n• `/givebal` - Transfer balance\n• `/convert-eur-usd` - Currency converter', inline: false },
                { name: '🎮 Coming Soon', value: '• Blackjack\n• Roulette\n• Slots', inline: true },
                { name: '🔧 Support', value: 'Need help? Staff can access this channel.', inline: true }
            )
            .setThumbnail(user.displayAvatarURL())
            .setTimestamp();
        
        await channel.send({ embeds: [welcomeEmbed] });
        
        console.log(`🏠 Private channel created: ${channel.name} for ${user.username}`);
        
        // Auto-close channel after 20 minutes
        setTimeout(async () => {
            try {
                const logManager = require('./utils/logManager.js');
                await logManager.sendBalanceLog(client, interaction.guild.id, {
                    type: 'channel_closed',
                    user: interaction.user,
                    details: 'Auto-close after 20 minutes'
                });
                
                await channel.delete('Auto-close after 20 minutes');
                console.log(`🔒 Auto-closed channel ${channel.name} after 20 minutes`);
            } catch (autoCloseError) {
                console.error('Error auto-closing channel:', autoCloseError);
            }
        }, 20 * 60 * 1000); // 20 minutes
        
    } catch (error) {
        console.error('❌ Create channel error:', error);
        
        const errorEmbed = new EmbedBuilder()
            .setColor('#ff0000')
            .setTitle('❌ Error')
            .setDescription('Failed to create private channel. Please contact staff.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

// Close Channel handler
async function handleCloseChannel(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    try {
        const channel = interaction.channel;
        
        // Log channel closure
        const logManager = require('./utils/logManager.js');
        await logManager.sendBalanceLog(client, interaction.guild.id, {
            type: 'channel_closed',
            user: interaction.user,
            details: 'Manually closed by user'
        });
        
        const confirmEmbed = new EmbedBuilder()
            .setColor('#ff6600')
            .setTitle('🔒 Channel Closing')
            .setDescription('This channel will be deleted in 5 seconds...')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [confirmEmbed] });
        
        // Delete channel after 5 seconds
        setTimeout(async () => {
            try {
                await channel.delete('Manually closed by user');
                console.log(`🔒 Channel ${channel.name} closed by ${interaction.user.username}`);
            } catch (deleteError) {
                console.error('Error deleting channel:', deleteError);
            }
        }, 5000);
        
    } catch (error) {
        console.error('❌ Close channel error:', error);
        
        const errorEmbed = new EmbedBuilder()
            .setColor('#ff0000')
            .setTitle('❌ Error')
            .setDescription('Unable to close the channel. Please try again.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

// Blackjack interaction handler
async function handleBlackjackInteraction(interaction) {
    const { activeGames, calculateHandValue, dealCard, createGameEmbed, createGameButtons } = require('./commands/blackjack.js');
    const userProfiles = require('./utils/userProfiles.js');
    const securityManager = require('./utils/securityManager.js');
    const logManager = require('./utils/logManager.js');
    const { formatLTC } = require('./utils/formatters.js');
    
    await interaction.deferUpdate();
    
    const userId = interaction.user.id;
    const game = activeGames.get(userId);
    
    if (!game || game.status !== 'playing') {
        return;
    }
    
    try {
        if (interaction.customId === 'blackjack_hit') {
            // Player hits
            game.playerHand.push(dealCard(game));
            game.playerValue = calculateHandValue(game.playerHand);
            game.canDoubleDown = false;
            
            if (game.playerValue > 21) {
                game.status = 'lost';
                activeGames.delete(userId);
                
                // Log the game
                await logManager.sendGamblingLog(client, interaction.guild.id, {
                    type: 'blackjack',
                    user: interaction.user,
                    game: 'blackjack',
                    bet: game.bet,
                    result: 'lose',
                    payout: 0,
                    details: `Player busted with ${game.playerValue}`
                });
            }
            
        } else if (interaction.customId === 'blackjack_stand') {
            // Player stands - dealer plays
            while (game.dealerValue < 17) {
                game.dealerHand.push(dealCard(game));
                game.dealerValue = calculateHandValue(game.dealerHand);
            }
            
            // Determine winner
            let payout = 0;
            if (game.dealerValue > 21) {
                game.status = 'won';
                payout = game.bet * 2;
            } else if (game.playerValue > game.dealerValue) {
                game.status = 'won';
                payout = game.bet * 2;
            } else if (game.playerValue < game.dealerValue) {
                game.status = 'lost';
                payout = 0;
            } else {
                game.status = 'push';
                payout = game.bet; // Return bet
            }
            
            // Update balance
            if (payout > 0) {
                const profile = userProfiles.getUserProfile(userId);
                userProfiles.updateUserProfile(userId, { 
                    balance: profile.balance + payout 
                });
            }
            
            // Log the game
            await logManager.sendGamblingLog(client, interaction.guild.id, {
                type: 'blackjack',
                user: interaction.user,
                game: 'blackjack',
                bet: game.bet,
                result: game.status === 'won' ? 'win' : game.status === 'lost' ? 'lose' : 'push',
                payout: payout,
                details: `Player: ${game.playerValue}, Dealer: ${game.dealerValue}`
            });
            
            activeGames.delete(userId);
            
        } else if (interaction.customId === 'blackjack_double') {
            // Player doubles down
            const profile = userProfiles.getUserProfile(userId);
            if (profile.balance >= game.bet) {
                userProfiles.updateUserProfile(userId, { 
                    balance: profile.balance - game.bet 
                });
                securityManager.addWageredAmount(userId, game.bet);
                
                game.bet *= 2;
                game.playerHand.push(dealCard(game));
                game.playerValue = calculateHandValue(game.playerHand);
                
                if (game.playerValue > 21) {
                    game.status = 'lost';
                } else {
                    // Dealer plays
                    while (game.dealerValue < 17) {
                        game.dealerHand.push(dealCard(game));
                        game.dealerValue = calculateHandValue(game.dealerHand);
                    }
                    
                    // Determine winner
                    let payout = 0;
                    if (game.dealerValue > 21 || game.playerValue > game.dealerValue) {
                        game.status = 'won';
                        payout = game.bet * 2;
                    } else if (game.playerValue < game.dealerValue) {
                        game.status = 'lost';
                        payout = 0;
                    } else {
                        game.status = 'push';
                        payout = game.bet;
                    }
                    
                    if (payout > 0) {
                        const updatedProfile = userProfiles.getUserProfile(userId);
                        userProfiles.updateUserProfile(userId, { 
                            balance: updatedProfile.balance + payout 
                        });
                    }
                }
                
                // Log the game
                await logManager.sendGamblingLog(client, interaction.guild.id, {
                    type: 'blackjack',
                    user: interaction.user,
                    game: 'blackjack',
                    bet: game.bet,
                    result: game.status === 'won' ? 'win' : game.status === 'lost' ? 'lose' : 'push',
                    payout: payout || 0,
                    details: `Double Down - Player: ${game.playerValue}, Dealer: ${game.dealerValue}`
                });
                
                activeGames.delete(userId);
            }
        }
        
        // Update the game display
        const gameEmbed = createGameEmbed(game, interaction.user);
        const gameButtons = createGameButtons(game);
        
        await interaction.editReply({ 
            embeds: [gameEmbed],
            components: game.status === 'playing' ? [gameButtons] : []
        });
        
    } catch (error) {
        console.error('Erreur blackjack interaction:', error);
    }
}

// Roulette interaction handler
async function handleRouletteInteraction(interaction) {
    const { activeSpins, spinWheel, calculatePayout, createResultEmbed, createBettingEmbed, createBettingComponents } = require('./commands/roulette.js');
    const userProfiles = require('./utils/userProfiles.js');
    const securityManager = require('./utils/securityManager.js');
    const logManager = require('./utils/logManager.js');
    const { formatLTC } = require('./utils/formatters.js');
    
    await interaction.deferUpdate();
    
    const userId = interaction.user.id;
    const spin = activeSpins.get(userId);
    
    if (!spin || spin.status !== 'betting') {
        return;
    }
    
    try {
        if (interaction.customId === 'roulette_spin') {
            if (spin.bets.size === 0) {
                return; // No bets placed
            }
            
            // Deduct total bet amount
            let totalBet = 0;
            for (const [, amount] of spin.bets) {
                totalBet += amount;
            }
            
            const profile = userProfiles.getUserProfile(userId);
            userProfiles.updateUserProfile(userId, { 
                balance: profile.balance - totalBet 
            });
            securityManager.addWageredAmount(userId, totalBet);
            
            // Spin the wheel
            const result = spinWheel();
            const { totalPayout, winningBets } = calculatePayout(spin.bets, result);
            
            // Add winnings to balance
            if (totalPayout > 0) {
                const updatedProfile = userProfiles.getUserProfile(userId);
                userProfiles.updateUserProfile(userId, { 
                    balance: updatedProfile.balance + totalPayout 
                });
            }
            
            // Log the game
            await logManager.sendGamblingLog(client, interaction.guild.id, {
                type: 'roulette',
                user: interaction.user,
                game: 'roulette',
                bet: totalBet,
                result: totalPayout > 0 ? 'win' : 'lose',
                payout: totalPayout,
                details: `Number ${result}, Total Bet: ${formatLTC(totalBet)} LTC`
            });
            
            // Check for big win (5x or more)
            if (totalPayout >= totalBet * 5) {
                await logManager.sendGamblingLog(client, interaction.guild.id, {
                    type: 'big_win',
                    user: interaction.user,
                    game: 'roulette',
                    bet: totalBet,
                    result: 'win',
                    payout: totalPayout
                });
            }
            
            spin.status = 'finished';
            spin.result = result;
            spin.totalPayout = totalPayout;
            
            const resultEmbed = createResultEmbed(spin, result, totalPayout, winningBets, interaction.user);
            
            await interaction.editReply({ 
                embeds: [resultEmbed],
                components: []
            });
            
            activeSpins.delete(userId);
            
        } else if (interaction.customId === 'roulette_clear') {
            spin.bets.clear();
            const bettingEmbed = createBettingEmbed(spin, interaction.user);
            const bettingComponents = createBettingComponents();
            
            await interaction.editReply({ 
                embeds: [bettingEmbed],
                components: bettingComponents
            });
            
        } else if (interaction.customId === 'roulette_cancel') {
            activeSpins.delete(userId);
            
            const cancelEmbed = new EmbedBuilder()
                .setColor('#ff6600')
                .setTitle('🚫 Roulette Cancelled')
                .setDescription('Your roulette game has been cancelled.')
                .setTimestamp();
            
            await interaction.editReply({ 
                embeds: [cancelEmbed],
                components: []
            });
            
        } else {
            // Handle bet buttons
            const betType = interaction.customId.replace('roulette_bet_', '');
            const betAmount = spin.bet / 4; // Split bet into quarters
            
            if (spin.bets.has(betType)) {
                spin.bets.set(betType, spin.bets.get(betType) + betAmount);
            } else {
                spin.bets.set(betType, betAmount);
            }
            
            const bettingEmbed = createBettingEmbed(spin, interaction.user);
            const bettingComponents = createBettingComponents();
            
            await interaction.editReply({ 
                embeds: [bettingEmbed],
                components: bettingComponents
            });
        }
        
    } catch (error) {
        console.error('Erreur roulette interaction:', error);
    }
}

// Roulette number bet handler
async function handleRouletteNumberBet(interaction) {
    const { activeSpins, createBettingEmbed, createBettingComponents } = require('./commands/roulette.js');
    
    await interaction.deferUpdate();
    
    const userId = interaction.user.id;
    const spin = activeSpins.get(userId);
    
    if (!spin || spin.status !== 'betting') {
        return;
    }
    
    try {
        const selectedValue = interaction.values[0];
        const betAmount = spin.bet / 4; // Split bet into quarters
        
        if (spin.bets.has(selectedValue)) {
            spin.bets.set(selectedValue, spin.bets.get(selectedValue) + betAmount);
        } else {
            spin.bets.set(selectedValue, betAmount);
        }
        
        const bettingEmbed = createBettingEmbed(spin, interaction.user);
        const bettingComponents = createBettingComponents();
        
        await interaction.editReply({ 
            embeds: [bettingEmbed],
            components: bettingComponents
        });
        
    } catch (error) {
        console.error('Erreur roulette number bet:', error);
    }
}

// Casino game quick start handlers
async function handleCasinoBlackjack(interaction) {
    await interaction.deferUpdate();
    
    const quickPlayEmbed = new EmbedBuilder()
        .setColor('#9932cc')
        .setTitle('🃏 Quick Play Blackjack')
        .setDescription('Ready to play Blackjack? Use the command `/blackjack <bet>` to start!')
        .addFields(
            {
                name: '🎯 How to Play',
                value: '• Beat the dealer by getting closer to 21 without going over\n• Face cards are worth 10, Aces are 1 or 11\n• You can Hit, Stand, or Double Down',
                inline: false
            },
            {
                name: '💰 Example Commands',
                value: '• `/blackjack bet:0.01` - Play with 0.01 LTC\n• `/blackjack bet:0.1` - Play with 0.1 LTC',
                inline: false
            }
        )
        .setFooter({ text: 'Good luck at the tables!' })
        .setTimestamp();
    
    await interaction.editReply({ embeds: [quickPlayEmbed] });
}

async function handleCasinoRoulette(interaction) {
    await interaction.deferUpdate();
    
    const quickPlayEmbed = new EmbedBuilder()
        .setColor('#9932cc')
        .setTitle('🎰 Quick Play Roulette')
        .setDescription('Ready to spin the wheel? Use the command `/roulette <bet>` to start!')
        .addFields(
            {
                name: '🎯 How to Play',
                value: '• Choose your bets: numbers (35:1), colors (1:1), even/odd (1:1)\n• The ball will land on a number from 0-36\n• Multiple bets allowed per spin',
                inline: false
            },
            {
                name: '💰 Example Commands',
                value: '• `/roulette bet:0.01` - Play with 0.01 LTC\n• `/roulette bet:0.1` - Play with 0.1 LTC',
                inline: false
            }
        )
        .setFooter({ text: 'Place your bets!' })
        .setTimestamp();
    
    await interaction.editReply({ embeds: [quickPlayEmbed] });
}

// Smart monitoring system
let monitoringInterval = null;

/**
 * Start smart monitoring for active deposits
 */
function startSmartMonitoring() {
    // Don't start if already running
    if (monitoringInterval) return;
    
    console.log('🔍 Démarrage de la surveillance des dépôts...');
    
    // Surveillance automatique toutes les 2 minutes pour respecter les limites API gratuites
    monitoringInterval = setInterval(async () => {
        try {
            const securityManager = require('./utils/securityManager.js');
            const userProfiles = require('./utils/userProfiles.js');
            
            // Get all active deposits
            const activeDeposits = securityManager.getAllActiveDeposits();
            
            if (activeDeposits.length === 0) {
                console.log('ℹ️  Aucun dépôt actif - arrêt de la surveillance');
                stopSmartMonitoring();
                return;
            }
            
            // Check for new deposits
            const detectedDeposits = await ltcWallet.smartDepositCheck(activeDeposits);
            
            // Process detected deposits
            for (const deposit of detectedDeposits) {
                try {
                    // Add deposit to user profile
                    userProfiles.addDeposit(deposit.userId, deposit.amount, deposit.address);
                    
                    // Add to deposited amount for cashout protection
                    securityManager.addDepositedAmount(deposit.userId, deposit.amount);
                    
                    // Mark deposit as completed
                    securityManager.completeDepositRequest(deposit.userId, deposit.address);
                    
                    // Notify user
                    await notifyUserOfDeposit(deposit);
                    
                } catch (error) {
                    console.error('Erreur traitement dépôt:', error);
                }
            }
            
        } catch (error) {
            console.error('Erreur surveillance intelligente:', error);
        }
    }, 120000); // Check every 2 minutes pour respecter les limites BlockCypher gratuit
}

/**
 * Stop smart monitoring
 */
function stopSmartMonitoring() {
    if (monitoringInterval) {
        clearInterval(monitoringInterval);
        monitoringInterval = null;
        console.log('🛑 Surveillance intelligente arrêtée');
    }
}

/**
 * Notify user of detected deposit
 */
async function notifyUserOfDeposit(deposit) {
    try {
        const user = await client.users.fetch(deposit.userId);
        
        if (user) {
            const depositEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Deposit Confirmed!')
                .setDescription('Your Litecoin deposit has been confirmed and added to your balance.')
                .addFields(
                    {
                        name: '💰 Deposit Amount',
                        value: `**${deposit.amount.toFixed(8)} LTC**`,
                        inline: true
                    },
                    {
                        name: '📍 Address',
                        value: `\`${deposit.address}\``,
                        inline: false
                    },
                    {
                        name: '🎰 Ready to Play',
                        value: 'Use `/casino` to start playing!\n**Note:** You must wager 100% of deposited amount before cashout.',
                        inline: false
                    }
                )
                .setThumbnail('https://cryptologos.cc/logos/litecoin-ltc-logo.png')
                .setTimestamp();
            
            // Try to send DM
            try {
                await user.send({ embeds: [depositEmbed] });
                console.log(`💰 Utilisateur ${user.username} notifié du dépôt de ${deposit.amount} LTC`);
            } catch (dmError) {
                console.log(`Impossible d'envoyer un MP à ${user.username}:`, dmError.message);
            }
        }
    } catch (error) {
        console.log('Impossible de notifier l\'utilisateur du dépôt:', error.message);
    }
}

// Export for external use
module.exports = {
    client,
    handleAddBalance,
    handleCreateChannel,
    startSmartMonitoring,
    stopSmartMonitoring
};

// Gestion d'erreurs globales pour éviter les déconnexions
process.on('uncaughtException', (error) => {
    console.error('⚠️ Erreur non gérée capturée:', error);
    console.log('🔄 Le bot continue de fonctionner...');
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('⚠️ Promesse rejetée non gérée:', reason);
    console.log('🔄 Le bot continue de fonctionner...');
});

// Gestion des erreurs Discord
client.on('error', (error) => {
    console.error('⚠️ Erreur client Discord:', error);
    console.log('🔄 Tentative de reconnexion...');
});

client.on('warn', (info) => {
    console.warn('⚠️ Avertissement Discord:', info);
});

client.on('disconnect', () => {
    console.log('⚠️ Bot déconnecté, tentative de reconnexion...');
});

client.on('reconnecting', () => {
    console.log('🔄 Reconnexion en cours...');
});

// Fonction de reconnexion automatique
async function startBotWithRetry() {
    const token = process.env.DISCORD_TOKEN;
    
    if (!token) {
        console.error('❌ DISCORD_TOKEN environment variable is required!');
        process.exit(1);
    }
    
    let retryCount = 0;
    const maxRetries = 5;
    
    while (retryCount < maxRetries) {
        try {
            await client.login(token);
            console.log('✅ Bot connecté avec succès!');
            break;
        } catch (error) {
            retryCount++;
            console.error(`❌ Échec de connexion (tentative ${retryCount}/${maxRetries}):`, error.message);
            
            if (retryCount < maxRetries) {
                const delay = retryCount * 5000; // Délai croissant: 5s, 10s, 15s...
                console.log(`⏳ Nouvelle tentative dans ${delay/1000}s...`);
                await new Promise(resolve => setTimeout(resolve, delay));
            } else {
                console.error('❌ Impossible de se connecter après plusieurs tentatives');
                process.exit(1);
            }
        }
    }
}

// New premium casino handlers
async function handleCreatePrivateSession(interaction) {
    const sessionManager = require('./utils/sessionManager.js');
    await interaction.deferReply({ ephemeral: false });
    
    try {
        const existingSession = sessionManager.isUserInSession(interaction.user.id);
        if (existingSession) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#e74c3c')
                .setTitle('❌ Session Active')
                .setDescription(`Vous êtes déjà dans une session!\n\n**Channel:** <#${existingSession.channelId}>`)
                .setTimestamp();
            
            await interaction.editReply({ embeds: [errorEmbed] });
            return;
        }

        const result = await sessionManager.createPrivateSession(
            interaction.guild,
            interaction.user,
            'general',
            { duration: 120, maxParticipants: 8 }
        );

        if (result.success) {
            const successEmbed = new EmbedBuilder()
                .setColor('#2ecc71')
                .setTitle('🎉 Session Privée Créée!')
                .setDescription(`**${result.channel}**\n\n🔑 Votre salon privé est prêt!`)
                .addFields({
                    name: '🎮 Fonctionnalités',
                    value: '• Inviter des amis\n• Jeux exclusifs\n• Paramètres personnalisés\n• Tournois privés',
                    inline: false
                })
                .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            const actionRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('🚀 Aller au Salon')
                        .setStyle(ButtonStyle.Link)
                        .setURL(`https://discord.com/channels/${interaction.guild.id}/${result.channel.id}`)
                );

            await interaction.editReply({ embeds: [successEmbed], components: [actionRow] });
        } else {
            throw new Error(result.error);
        }
    } catch (error) {
        console.error('Error creating private session:', error);
        const errorEmbed = new EmbedBuilder()
            .setColor('#e74c3c')
            .setTitle('❌ Erreur')
            .setDescription('Impossible de créer la session privée.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

async function handleQuickGame(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    const quickGameEmbed = new EmbedBuilder()
        .setColor('#f39c12')
        .setTitle('⚡ JEU RAPIDE')
        .setDescription('**Choisissez votre aventure instantanée!**')
        .addFields(
            {
                name: '🎯 Modes Disponibles',
                value: '```yaml\n🎲 Dés Rapides: Mise minimale 0.001 LTC\n🃏 Blackjack Express: Partie en 30 secondes\n🎰 Roulette Turbo: Résultat immédiat\n💎 Lucky Spin: Jackpot surprise\n```',
                inline: false
            }
        )
        .setThumbnail('https://media.giphy.com/media/l0ErLeqamV3UOARsA/giphy.gif')
        .setTimestamp();

    const gamesRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('quick_dice')
                .setLabel('🎲 Dés Rapides')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('quick_blackjack')
                .setLabel('🃏 BJ Express')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('quick_roulette')
                .setLabel('🎰 Roulette Turbo')
                .setStyle(ButtonStyle.Danger)
        );

    await interaction.editReply({ embeds: [quickGameEmbed], components: [gamesRow] });
}

async function handleTournaments(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    const tournamentsEmbed = new EmbedBuilder()
        .setColor('#9b59b6')
        .setTitle('🏆 TOURNOIS PREMIUM')
        .setDescription('**Affrontez les meilleurs joueurs du casino!**')
        .addFields(
            {
                name: '🔥 Tournois Actifs',
                value: '```diff\n+ 🃏 Blackjack Championship (Prize: 5 LTC)\n+ 🎰 Roulette Masters (Prize: 3 LTC)\n+ 🎲 Dice Tournament (Prize: 2 LTC)\n- 💎 VIP Exclusive (Prize: 10 LTC) [VIP Only]\n```',
                inline: false
            },
            {
                name: '📅 Prochains Événements',
                value: '• **Lundi:** Tournoi Hebdomadaire\n• **Mercredi:** Speed Gaming\n• **Vendredi:** High Stakes\n• **Dimanche:** Championship',
                inline: true
            },
            {
                name: '🎁 Récompenses',
                value: '• **1er:** 50% du pot\n• **2ème:** 30% du pot\n• **3ème:** 20% du pot\n• **Participants:** Bonus XP',
                inline: true
            }
        )
        .setImage('https://media.giphy.com/media/l0HlCDAdh4jJGh8Pu/giphy.gif')
        .setTimestamp();

    const actionRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('join_tournament')
                .setLabel('🎯 Rejoindre')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('tournament_rules')
                .setLabel('📜 Règles')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('tournament_leaderboard')
                .setLabel('🏆 Classement')
                .setStyle(ButtonStyle.Primary)
        );

    await interaction.editReply({ embeds: [tournamentsEmbed], components: [actionRow] });
}

async function handleCasinoCoinflip(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    const coinflipEmbed = new EmbedBuilder()
        .setColor('#f39c12')
        .setTitle('🪙 COIN FLIP CASINO')
        .setDescription('**Test your luck with a classic coin flip!**')
        .addFields(
            {
                name: '🎯 How to Play',
                value: '• Choose heads or tails\n• Place your bet\n• Win 2x your bet if you guess correctly!\n• Simple 50/50 odds',
                inline: false
            },
            {
                name: '💰 Betting Limits',
                value: '**Minimum:** 0.001 LTC\n**Maximum:** Based on casino funds (30%)\n**Payout:** 2:1 (double your bet)',
                inline: true
            },
            {
                name: '🚀 Quick Start',
                value: 'Use `/coinflip amount:0.01 choice:heads` to start playing!',
                inline: true
            }
        )
        .setThumbnail('https://media.giphy.com/media/l0ErFafpUCQTQFMSk/giphy.gif')
        .setTimestamp();

    const actionRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('coinflip_quick_heads')
                .setLabel('🦅 Quick Heads (0.001)')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('coinflip_quick_tails')
                .setLabel('⚡ Quick Tails (0.001)')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('coinflip_custom')
                .setLabel('🎯 Custom Game')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.editReply({ embeds: [coinflipEmbed], components: [actionRow] });
}

async function handleCasinoHelp(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    const helpEmbed = new EmbedBuilder()
        .setColor('#3498db')
        .setTitle('🎓 VIP CASINO GUIDE')
        .setDescription('**Master all aspects of our premium casino!**')
        .addFields(
            {
                name: '💰 Gestion des Fonds',
                value: '```yaml\nDépôt: Adresses uniques générées\nRetrait: Protection par mot de passe\nSécurité: Système de wagering 100%\nLimites: Configurables par session\n```',
                inline: false
            },
            {
                name: '🎮 Jeux Disponibles',
                value: '• **🃏 Blackjack:** Stratégie classique\n• **🎰 Roulette:** Européenne & Américaine\n• **🎲 Dés:** Multiple variations\n• **🏆 Tournois:** Compétitions régulières',
                inline: true
            },
            {
                name: '🚀 Fonctions Avancées',
                value: '• **Sessions Privées:** Jeu entre amis\n• **Jeu Rapide:** Parties instantanées\n• **Programme VIP:** Récompenses exclusives\n• **Support 24/7:** Assistance permanente',
                inline: true
            },
            {
                name: '🔧 Commandes Principales',
                value: '`/casino` - Panel principal\n`/profile` - Votre profil\n`/createsession` - Session privée\n`/balance` - Vérifier solde\n`/cashout` - Retirer gains',
                inline: false
            }
        )
        .setFooter({ text: '💡 Conseil: Utilisez /createsession pour jouer avec vos amis!' })
        .setTimestamp();

    const helpRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('help_deposit')
                .setLabel('💳 Aide Dépôt')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('help_games')
                .setLabel('🎮 Aide Jeux')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('help_withdrawal')
                .setLabel('💰 Aide Retrait')
                .setStyle(ButtonStyle.Success)
        );

    await interaction.editReply({ embeds: [helpEmbed], components: [helpRow] });
}

async function handleSessionInteraction(interaction) {
    const sessionManager = require('./utils/sessionManager.js');
    await interaction.deferReply({ ephemeral: false });
    
    try {
        const parts = interaction.customId.split('_');
        const action = parts[1]; // invite, settings, blackjack, etc.
        const sessionId = parts.slice(2).join('_'); // session ID
        
        const session = sessionManager.getSession(sessionId);
        if (!session) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#e74c3c')
                .setTitle('❌ Session Introuvable')
                .setDescription('Cette session n\'existe plus ou a expiré.')
                .setTimestamp();
            
            await interaction.editReply({ embeds: [errorEmbed] });
            return;
        }
        
        // Check if user is in session (except for invite action)
        if (action !== 'invite' && !session.participants.includes(interaction.user.id)) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#e74c3c')
                .setTitle('❌ Accès Refusé')
                .setDescription('Vous n\'êtes pas participant de cette session.')
                .setTimestamp();
            
            await interaction.editReply({ embeds: [errorEmbed] });
            return;
        }
        
        switch (action) {
            case 'invite':
                await handleSessionInvite(interaction, sessionId);
                break;
            case 'settings':
                await handleSessionSettings(interaction, sessionId);
                break;
            case 'blackjack':
                await handleSessionBlackjack(interaction, sessionId);
                break;
            case 'roulette':
                await handleSessionRoulette(interaction, sessionId);
                break;
            case 'close':
                await handleSessionClose(interaction, sessionId);
                break;
            case 'stats':
                await handleSessionStats(interaction, sessionId);
                break;
            default:
                throw new Error(`Action inconnue: ${action}`);
        }
        
    } catch (error) {
        console.error('Session interaction error:', error);
        const errorEmbed = new EmbedBuilder()
            .setColor('#e74c3c')
            .setTitle('❌ Erreur Session')
            .setDescription('Une erreur est survenue lors de la gestion de la session.')
            .setTimestamp();
        
        if (interaction.deferred && !interaction.replied) {
            await interaction.editReply({ embeds: [errorEmbed] });
        }
    }
}

async function handleGameAgain(interaction) {
    const testgambleCommand = require('./commands/testgamble.js');
    
    // Extract bet amount from button ID
    let amount = 0.001;
    if (interaction.customId.includes('medium')) amount = 0.01;
    if (interaction.customId.includes('big')) amount = 0.1;
    
    // Create a mock interaction object for testgamble
    const mockInteraction = {
        ...interaction,
        options: {
            getNumber: () => amount
        }
    };
    
    await testgambleCommand.execute(mockInteraction);
}

async function handleQuickCashout(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    const helpEmbed = new EmbedBuilder()
        .setColor('#f39c12')
        .setTitle('💰 Quick Cashout')
        .setDescription('To cashout your winnings, use the `/cashout` command with your destination address and password.')
        .addFields({
            name: '📝 Example',
            value: '`/cashout address:LTC_ADDRESS amount:0.05 password:your_password`',
            inline: false
        })
        .setTimestamp();
    
    await interaction.editReply({ embeds: [helpEmbed] });
}

async function handleCoinflipAgain(interaction) {
    const coinflipCommand = require('./commands/coinflip.js');
    
    // Extract bet amount from button ID
    let amount = 0.001;
    if (interaction.customId.includes('medium')) amount = 0.01;
    if (interaction.customId.includes('big')) amount = 0.1;
    
    // Random choice for quick play
    const choices = ['heads', 'tails'];
    const randomChoice = choices[Math.floor(Math.random() * choices.length)];
    
    // Create a mock interaction object for coinflip
    const mockInteraction = {
        ...interaction,
        options: {
            getNumber: () => amount,
            getString: () => randomChoice
        }
    };
    
    await coinflipCommand.execute(mockInteraction);
}

async function handleQuickCoinflip(interaction) {
    const coinflipCommand = require('./commands/coinflip.js');
    
    // Extract choice from button ID
    const choice = interaction.customId.includes('heads') ? 'heads' : 'tails';
    const amount = 0.001; // Quick play amount
    
    // Create a mock interaction object for coinflip
    const mockInteraction = {
        ...interaction,
        options: {
            getNumber: () => amount,
            getString: () => choice
        }
    };
    
    await coinflipCommand.execute(mockInteraction);
}

// Session management handlers
async function handleSessionInvite(interaction, sessionId) {
    const embed = new EmbedBuilder()
        .setColor('#3498db')
        .setTitle('👥 Inviter des Joueurs')
        .setDescription('Pour inviter quelqu\'un à votre session, utilisez `/createsession` et partagez le lien du canal privé.')
        .setTimestamp();
    
    await interaction.editReply({ embeds: [embed] });
}

async function handleSessionSettings(interaction, sessionId) {
    const embed = new EmbedBuilder()
        .setColor('#f39c12')
        .setTitle('⚙️ Paramètres de Session')
        .setDescription('Les paramètres de session peuvent être modifiés par l\'hôte.')
        .setTimestamp();
    
    await interaction.editReply({ embeds: [embed] });
}

async function handleSessionBlackjack(interaction, sessionId) {
    // Start blackjack in session context
    const blackjackCommand = require('./commands/blackjack.js');
    await blackjackCommand.execute(interaction);
}

async function handleSessionRoulette(interaction, sessionId) {
    // Start roulette in session context
    const rouletteCommand = require('./commands/roulette.js');
    await rouletteCommand.execute(interaction);
}

async function handleSessionClose(interaction, sessionId) {
    const sessionManager = require('./utils/sessionManager.js');
    const session = sessionManager.getSession(sessionId);
    
    if (session && session.hostId === interaction.user.id) {
        await sessionManager.closeSession(sessionId, interaction.guild);
        const embed = new EmbedBuilder()
            .setColor('#95a5a6')
            .setTitle('🔒 Session Fermée')
            .setDescription('La session privée a été fermée avec succès.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [embed] });
    } else {
        const embed = new EmbedBuilder()
            .setColor('#e74c3c')
            .setTitle('❌ Permission Refusée')
            .setDescription('Seul l\'hôte peut fermer la session.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [embed] });
    }
}

async function handleSessionStats(interaction, sessionId) {
    const sessionManager = require('./utils/sessionManager.js');
    const session = sessionManager.getSession(sessionId);
    
    if (session) {
        const embed = new EmbedBuilder()
            .setColor('#9b59b6')
            .setTitle('📊 Statistiques de Session')
            .addFields(
                {
                    name: '🎮 Informations',
                    value: `**Type:** ${session.sessionType}\n**Hôte:** <@${session.hostId}>\n**Participants:** ${session.participants.length}/${session.settings.maxParticipants}`,
                    inline: true
                },
                {
                    name: '📈 Activité',
                    value: `**Jeux joués:** ${session.stats.totalGames}\n**Mises totales:** ${session.stats.totalWagers.toFixed(8)} LTC`,
                    inline: true
                }
            )
            .setTimestamp();
        
        await interaction.editReply({ embeds: [embed] });
    }
}

// Channel management handlers
async function handleGenerateAddress(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    try {
        const channelId = interaction.customId.split('_')[2];
        const channelManager = require('./utils/channelManager.js');
        
        // Verify this is the channel owner
        const channelInfo = channelManager.getChannelInfo(channelId);
        if (!channelInfo || channelInfo.userId !== interaction.user.id) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#e74c3c')
                .setTitle('❌ Access Denied')
                .setDescription('You can only generate addresses in your own deposit channel.')
                .setTimestamp();
            
            await interaction.editReply({ embeds: [errorEmbed] });
            return;
        }

        // Generate address (we already generated it in handleAddBalance, but let's generate a new one)
        const newAddress = ltcWallet.generateAddress();
        if (!newAddress) {
            throw new Error('Failed to generate Litecoin address');
        }

        const addressEmbed = new EmbedBuilder()
            .setColor('#f39c12')
            .setTitle('📍 Your Deposit Address')
            .setDescription('Send Litecoin to this address to add balance to your account.')
            .addFields(
                {
                    name: '💳 Deposit Address',
                    value: `\`\`\`${newAddress.address}\`\`\``,
                    inline: false
                },
                {
                    name: '⚡ Detection',
                    value: 'Deposits are detected within 30 seconds',
                    inline: true
                },
                {
                    name: '✅ Confirmation',
                    value: 'Balance added after 1 confirmation',
                    inline: true
                },
                {
                    name: '🔒 Security',
                    value: 'This address is unique to this deposit',
                    inline: false
                }
            )
            .setThumbnail('https://cryptologos.cc/logos/litecoin-ltc-logo.png')
            .setTimestamp();

        const copyRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`copy_address_${newAddress.address}`)
                    .setLabel('📋 Copy Address')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('📋')
            );

        await interaction.editReply({
            embeds: [addressEmbed],
            components: [copyRow]
        });

        console.log(`📍 Adresse générée dans channel ${channelId}: ${newAddress.address}`);

    } catch (error) {
        console.error('Erreur génération adresse:', error);
        
        const errorEmbed = new EmbedBuilder()
            .setColor('#e74c3c')
            .setTitle('❌ Error')
            .setDescription('Failed to generate deposit address.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

async function handleCancelDeposit(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    const channelId = interaction.customId.split('_')[2];
    
    const confirmEmbed = new EmbedBuilder()
        .setColor('#f39c12')
        .setTitle('⚠️ Confirm Cancellation')
        .setDescription('Are you sure you want to cancel this deposit and close this channel?')
        .addFields({
            name: '🗑️ What happens next',
            value: '• This channel will be deleted\n• Any pending deposits will still be processed\n• You can create a new deposit channel anytime',
            inline: false
        })
        .setTimestamp();

    const confirmRow = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`confirm_cancel_${channelId}`)
                .setLabel('✅ Yes, Cancel & Close')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('✅'),
            new ButtonBuilder()
                .setCustomId(`keep_channel_${channelId}`)
                .setLabel('❌ No, Keep Channel')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('❌')
        );

    await interaction.editReply({
        embeds: [confirmEmbed],
        components: [confirmRow]
    });
}

async function handleConfirmCancel(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    const channelId = interaction.customId.split('_')[2];
    const channelManager = require('./utils/channelManager.js');
    
    try {
        const closingEmbed = new EmbedBuilder()
            .setColor('#95a5a6')
            .setTitle('👋 Channel Closing')
            .setDescription('This deposit channel will be deleted in 5 seconds.')
            .addFields({
                name: '✅ Thanks for using our service!',
                value: 'You can create a new deposit channel anytime using the casino panel.',
                inline: false
            })
            .setTimestamp();

        await interaction.editReply({ embeds: [closingEmbed], components: [] });

        // Delete channel after 5 seconds
        setTimeout(async () => {
            try {
                const channel = interaction.guild.channels.cache.get(channelId);
                if (channel) {
                    channelManager.unregisterChannel(channelId);
                    await channel.delete('User cancelled deposit');
                    console.log(`🗑️ Channel ${channelId} fermé par l'utilisateur`);
                }
            } catch (error) {
                console.error('Erreur fermeture channel:', error);
            }
        }, 5000);

    } catch (error) {
        console.error('Erreur confirmation cancel:', error);
    }
}

async function handleCopyAddress(interaction) {
    const address = interaction.customId.split('_')[2];
    
    const copyEmbed = new EmbedBuilder()
        .setColor('#2ecc71')
        .setTitle('📋 Address Copied!')
        .setDescription(`**Address:** \`${address}\``)
        .addFields({
            name: '💡 Tip',
            value: 'You can now paste this address in your Litecoin wallet.',
            inline: false
        })
        .setTimestamp();

    await interaction.reply({
        embeds: [copyEmbed],
        ephemeral: true
    });

    console.log(`📋 Utilisateur ${interaction.user.username} a copié l'adresse ${address}`);
}

async function handleKeepChannel(interaction) {
    await interaction.deferReply({ ephemeral: false });
    
    const keepEmbed = new EmbedBuilder()
        .setColor('#2ecc71')
        .setTitle('✅ Channel Preserved')
        .setDescription('Your deposit channel will remain open. You can continue using it for deposits.')
        .addFields({
            name: '💡 What you can do',
            value: '• Generate new deposit addresses\n• Monitor your deposits\n• Close the channel when ready',
            inline: false
        })
        .setTimestamp();

    await interaction.editReply({ embeds: [keepEmbed], components: [] });
    console.log(`✅ Utilisateur ${interaction.user.username} a gardé son channel`);
}

// Start the bot if this file is run directly
if (require.main === module) {
    startBotWithRetry();
}