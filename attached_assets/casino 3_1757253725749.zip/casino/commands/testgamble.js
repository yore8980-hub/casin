const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const treasuryManager = require('../utils/treasuryManager.js');
const securityManager = require('../utils/securityManager.js');
const userProfiles = require('../utils/userProfiles.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('testgamble')
        .setDescription('Test gambling command to simulate wagering (requires active session)')
        .addNumberOption(option =>
            option.setName('amount')
                .setDescription('Amount to wager in LTC')
                .setRequired(true)
                .setMinValue(0.001)
        ),
    
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: false });
        
        try {
            const amount = interaction.options.getNumber('amount');
            const userId = interaction.user.id;
            
            // Check if user has active gambling session
            if (!securityManager.hasActiveGamblingSession(userId)) {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('❌ No Active Session')
                    .setDescription('You need to enable a gambling session first using `/enable`.')
                    .addFields({
                        name: '🔒 How to Start',
                        value: 'Use `/enable [minutes] [password]` to start a gambling session.',
                        inline: false
                    })
                    .setTimestamp();
                
                await interaction.editReply({ embeds: [errorEmbed] });
                return;
            }
            
            // Check user balance
            const profile = userProfiles.getUserProfile(userId);
            
            // Check treasury bet limits
            const maxBet = treasuryManager.getMaxBetLimit();
            if (amount > maxBet) {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#e74c3c')
                    .setTitle('❌ Mise Trop Élevée')
                    .setDescription(`La mise maximum autorisée est ${maxBet.toFixed(8)} LTC (30% des fonds du casino).`)
                    .addFields({
                        name: '💰 Limites Actuelles',
                        value: `**Votre mise:** ${amount.toFixed(8)} LTC\n**Maximum autorisé:** ${maxBet.toFixed(8)} LTC\n**Fonds casino:** ${treasuryManager.getCurrentBalance().toFixed(8)} LTC`,
                        inline: false
                    })
                    .setTimestamp();
                
                await interaction.editReply({ embeds: [errorEmbed] });
                return;
            }
            
            if (profile.balance < amount) {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('❌ Insufficient Balance')
                    .setDescription('You don\'t have enough balance to wager this amount.')
                    .addFields({
                        name: '💰 Available Balance',
                        value: `${profile.balance.toFixed(8)} LTC`,
                        inline: true
                    })
                    .setTimestamp();
                
                await interaction.editReply({ embeds: [errorEmbed] });
                return;
            }
            
            // Simulate gambling result (50/50 chance for testing)
            const won = Math.random() > 0.5;
            const resultAmount = won ? amount * 1.8 : 0; // 1.8x payout if win
            
            // Record treasury transaction
            if (won) {
                treasuryManager.recordPayout(amount * 0.8, interaction.user.id, 'testgamble', {
                    originalAmount: amount,
                    winAmount: resultAmount
                });
            } else {
                treasuryManager.recordHouseWin(amount, interaction.user.id, 'testgamble', {
                    lostAmount: amount
                });
            }
            
            // Update balance
            const newBalance = profile.balance - amount + resultAmount;
            userProfiles.updateUserProfile(userId, { balance: newBalance });
            
            // Add wagered amount (for cashout protection)
            securityManager.addWageredAmount(userId, amount);
            
            // Check new cashout status
            const cashoutStatus = securityManager.canUserCashout(userId);
            
            // Create animated result embed
            const resultEmbed = this.createGameResultEmbed(won, amount, resultAmount, profile.balance, newBalance, cashoutStatus, interaction.user);
            
            // Create action buttons for continuing play
            const actionRow = this.createGameActionButtons(newBalance, cashoutStatus.canCashout);
            
            await interaction.editReply({ 
                embeds: [resultEmbed],
                components: actionRow ? [actionRow] : []
            });
            
            console.log(`🎲 ${interaction.user.username} ${won ? 'won' : 'lost'} ${amount} LTC - Balance: ${newBalance.toFixed(8)} LTC`);
            
        } catch (error) {
            console.error('Test gamble error:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Game Error')
                .setDescription('An error occurred during the game. Please try again.')
                .setTimestamp();
            
            await interaction.editReply({ embeds: [errorEmbed] });
        }
    },

    createGameResultEmbed(won, amount, resultAmount, oldBalance, newBalance, cashoutStatus, user) {
        const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
        const { formatLTC } = require('../utils/formatters.js');
        
        // Determine colors and effects based on result
        let color, title, description, thumbnail;
        
        if (won) {
            color = '#2ecc71'; // Beautiful green
            title = '🎉 VICTOIRE ÉCLATANTE! 🎉';
            description = `**Félicitations ${user.username}!**\n✨ Vous avez remporté une magnifique victoire! ✨`;
            thumbnail = 'https://cdn.discordapp.com/emojis/853619443004760064.gif'; // Victory animation
        } else {
            color = '#e74c3c'; // Elegant red
            title = '🎯 Pas de chance cette fois...';
            description = `**Courage ${user.username}!**\n🔄 La chance va tourner, continuez à jouer!`;
            thumbnail = 'https://cdn.discordapp.com/emojis/853619442987982849.gif'; // Retry animation
        }

        const embed = new EmbedBuilder()
            .setColor(color)
            .setTitle(title)
            .setDescription(description)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .addFields(
                {
                    name: '🎲 Résultat du Jeu',
                    value: `\`\`\`\n💸 Mise: ${formatLTC(amount)} LTC\n${won ? '💰' : '💥'} ${won ? 'Gain' : 'Perte'}: ${formatLTC(resultAmount)} LTC\n📊 Net: ${won ? '+' : ''}${formatLTC(resultAmount - amount)} LTC\n\`\`\``,
                    inline: false
                },
                {
                    name: '💎 Évolution du Solde',
                    value: `\`\`\`diff\n- Ancien: ${formatLTC(oldBalance)} LTC\n+ Nouveau: ${formatLTC(newBalance)} LTC\n\`\`\``,
                    inline: true
                },
                {
                    name: '🎯 Statut de Retrait',
                    value: `\`\`\`yaml\nProgrès: ${cashoutStatus.wageredPercent.toFixed(1)}%\nRetrait: ${cashoutStatus.canCashout ? '✅ Autorisé' : '❌ Bloqué'}\nRestant: ${formatLTC(cashoutStatus.remainingToWager)} LTC\n\`\`\``,
                    inline: true
                }
            )
            .setFooter({ 
                text: `🎰 ${won ? 'Bravo!' : 'Bonne chance!'} • Session de ${user.username}`,
                iconURL: 'https://cryptologos.cc/logos/litecoin-ltc-logo.png'
            })
            .setTimestamp();

        // Add special effects for big wins
        if (won && resultAmount > amount * 2) {
            embed.setImage('https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif'); // Celebration GIF
        }

        return embed;
    },

    createGameActionButtons(balance, canCashout) {
        const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
        
        if (balance < 0.001) return null; // No buttons if broke
        
        const actionRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('game_again_small')
                    .setLabel('🎲 Rejouer (0.001)')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🎲'),
                new ButtonBuilder()
                    .setCustomId('game_again_medium')
                    .setLabel('🎯 Mise Moyenne (0.01)')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🎯')
                    .setDisabled(balance < 0.01),
                new ButtonBuilder()
                    .setCustomId('game_again_big')
                    .setLabel('💎 Gros Jeu (0.1)')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('💎')
                    .setDisabled(balance < 0.1)
            );

        if (canCashout) {
            actionRow.addComponents(
                new ButtonBuilder()
                    .setCustomId('quick_cashout')
                    .setLabel('💰 Retirer')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('💰')
            );
        }

        return actionRow;
    }
};