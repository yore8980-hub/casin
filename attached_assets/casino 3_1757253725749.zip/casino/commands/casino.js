const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('casino')
        .setDescription('Open the casino main panel'),
    
    async execute(interaction) {
        // Check if interaction is too old
        const interactionAge = Date.now() - interaction.createdTimestamp;
        if (interactionAge > 10 * 60 * 1000) {
            console.log('Interaction trop ancienne, ignorée');
            return;
        }
        
        try {
            const casinoEmbed = new EmbedBuilder()
                .setColor('#9b59b6')
                .setTitle('🎰 ◆ PREMIUM LITECOIN CASINO ◆ 🎰')
                .setDescription('**Welcome to the most luxurious gaming experience!**\n\n✨ *Get ready for unforgettable moments* ✨')
                .addFields(
                    {
                        name: '💎 VIP LOUNGE',
                        value: '```yaml\n🏆 Private Sessions\n👥 Group Games\n🎯 Exclusive Tournaments\n```',
                        inline: true
                    },
                    {
                        name: '🎮 PREMIUM GAMES',
                        value: '```diff\n+ 🃏 Professional Blackjack\n+ 🎰 European Roulette\n+ 🪙 Coin Flip\n+ 🎲 Luxury Dice\n+ 🎪 Weekly Tournaments\n```',
                        inline: true
                    },
                    {
                        name: '💰 SECURE FINANCE',
                        value: '```css\n[Instant Deposits]\n[Fast Withdrawals]\n[Secure Crypto]\n[Daily Bonuses]\n```',
                        inline: true
                    },
                    {
                        name: '🌟 MEMBER BENEFITS',
                        value: '• 🎁 **Welcome bonus** for new players\n• 🔄 **Daily cashback** on your bets\n• 🏅 **VIP program** with rewards\n• 📞 **24/7 support** from our team',
                        inline: false
                    }
                )
                .setThumbnail('https://cryptologos.cc/logos/litecoin-ltc-logo.png')
                .setImage('https://media.giphy.com/media/xTiTnqUxyWbsAXq7Ju/giphy.gif')
                .setFooter({ 
                    text: '🔒 Secure • ⚡ Instant • 🌍 Transparent • 🏆 Premium',
                    iconURL: 'https://cryptologos.cc/logos/litecoin-ltc-logo.png'
                })
                .setTimestamp();
            
            const actionRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('add_balance')
                        .setLabel('💰 Deposit Money')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('💰'),
                    new ButtonBuilder()
                        .setCustomId('view_profile')
                        .setLabel('👑 My VIP Profile')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('👑'),
                    new ButtonBuilder()
                        .setCustomId('leaderboard')
                        .setLabel('🏆 Hall of Fame')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🏆')
                );
            
            // Premium games row
            const gamesRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('casino_blackjack')
                        .setLabel('🃏 Blackjack Pro')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('🃏'),
                    new ButtonBuilder()
                        .setCustomId('casino_roulette')
                        .setLabel('🎰 Roulette Royale')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('🎰'),
                    new ButtonBuilder()
                        .setCustomId('casino_coinflip')
                        .setLabel('🪙 Coin Flip')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('🪙'),
                    new ButtonBuilder()
                        .setCustomId('create_private_session')
                        .setLabel('🏠 Private Session')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🏠')
                );
            
            // Add session info row
            const sessionRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('quick_game')
                        .setLabel('⚡ Quick Game')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('⚡'),
                    new ButtonBuilder()
                        .setCustomId('tournaments')
                        .setLabel('🏅 Tournaments')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🏅'),
                    new ButtonBuilder()
                        .setCustomId('casino_help')
                        .setLabel('❓ VIP Guide')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('❓')
                );

            await interaction.reply({ 
                embeds: [casinoEmbed], 
                components: [actionRow, gamesRow, sessionRow]
            });
            
        } catch (error) {
            console.error('Casino command error:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ System Error')
                .setDescription('Unable to load casino. Our technical team is working to resolve this issue.')
                .setTimestamp();
            
            try {
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
                } else {
                    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }
            } catch (replyError) {
                console.error('Impossible de répondre à l\'erreur casino:', replyError.message);
            }
        }
    }
};