const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Import Litecoin wallet system
const ltcWallet = require('./litecoin-casino-bot.js');

// Create Discord client
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// Commands collection
client.commands = new Collection();

// Load commands
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);
        
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
            console.log(`✅ Commande chargée: ${command.data.name}`);
        } else {
            console.log(`⚠️  Commande ${file} manque des propriétés requises`);
        }
    }
}

// Load events
const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    
    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args));
        } else {
            client.on(event.name, (...args) => event.execute(...args));
        }
        console.log(`✅ Événement chargé: ${event.name}`);
    }
}


// Interaction handling
client.on(Events.InteractionCreate, async interaction => {
    // Handle slash commands
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        
        if (!command) {
            console.error(`❌ Aucune commande correspondant à ${interaction.commandName} trouvée.`);
            return;
        }
        
        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(`❌ Erreur lors de l'exécution de ${interaction.commandName}:`, error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Error')
                .setDescription('There was an error while executing this command!')
                .setTimestamp();
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    }
    
    // Handle button interactions
    if (interaction.isButton()) {
        try {
            // Add Balance button
            if (interaction.customId === 'add_balance') {
                await handleAddBalance(interaction);
            }
            // Create channel button
            else if (interaction.customId === 'create_channel') {
                await handleCreateChannel(interaction);
            }
            // Other button handlers can be added here
        } catch (error) {
            console.error('❌ Erreur d\'interaction bouton:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Error')
                .setDescription('There was an error processing your request!')
                .setTimestamp();
            
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
            } else {
                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        }
    }
});

// Add Balance handler
async function handleAddBalance(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    try {
        // Generate new LTC address for each deposit request
        const newAddress = ltcWallet.generateAddress();
        
        if (!newAddress) {
            throw new Error('Failed to generate Litecoin address');
        }
        
        // Link address to user and add to active deposits monitoring
        const userProfiles = require('./utils/userProfiles.js');
        const securityManager = require('./utils/securityManager.js');
        
        await userProfiles.linkAddressToUser(interaction.user.id, newAddress.address);
        securityManager.addActiveDeposit(interaction.user.id, newAddress.address, 0);
        
        // Start smart monitoring for this deposit
        startSmartMonitoring();
        
        const depositEmbed = new EmbedBuilder()
            .setColor('#f7931a')
            .setTitle('💰 Add Balance - New Litecoin Address')
            .setDescription('Send the amount you want to deposit to the **new unique address** below:')
            .addFields(
                { name: '📍 Deposit Address (NEW)', value: `\`${newAddress.address}\``, inline: false },
                { name: '⏱️ Smart Detection', value: 'Monitoring active - deposits detected within 30 seconds', inline: true },
                { name: '🔄 Status', value: 'Waiting for deposit...', inline: true },
                { name: '🔒 Security', value: 'This address is unique to this deposit request', inline: false }
            )
            .setThumbnail('https://cryptologos.cc/logos/litecoin-ltc-logo.png')
            .setFooter({ text: 'Casino Bot • Smart Monitoring Active' })
            .setTimestamp();
        
        // Create channel button
        const channelButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('create_channel')
                    .setLabel('🎫 Create Private Channel')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🎫')
            );
        
        await interaction.editReply({ 
            embeds: [depositEmbed],
            components: [channelButton]
        });
        
        // Send address as plain text in a separate message
        await interaction.followUp({
            content: newAddress.address,
            ephemeral: true
        });
        
        console.log(`🔍 Surveillance démarrée pour l'adresse ${newAddress.address} (utilisateur ${interaction.user.username})`);
        
    } catch (error) {
        console.error('❌ Add balance error:', error);
        
        const errorEmbed = new EmbedBuilder()
            .setColor('#ff0000')
            .setTitle('❌ Error')
            .setDescription('Failed to generate deposit address. Please try again.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

// Create Channel handler
async function handleCreateChannel(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    try {
        const guild = interaction.guild;
        const user = interaction.user;
        
        // Check if user already has a channel
        const existingChannel = guild.channels.cache.find(channel => 
            channel.name === `casino-${user.username.toLowerCase()}` && 
            channel.type === 0 // Text channel
        );
        
        if (existingChannel) {
            const alreadyExistsEmbed = new EmbedBuilder()
                .setColor('#ffaa00')
                .setTitle('⚠️ Channel Already Exists')
                .setDescription(`You already have a private channel: ${existingChannel}`)
                .setTimestamp();
            
            await interaction.editReply({ embeds: [alreadyExistsEmbed] });
            return;
        }
        
        // Create private channel
        const channel = await guild.channels.create({
            name: `casino-${user.username.toLowerCase()}`,
            type: 0, // Text channel
            topic: `Private casino session for ${user.username}`,
            permissionOverwrites: [
                {
                    id: guild.id,
                    deny: ['ViewChannel', 'SendMessages']
                },
                {
                    id: user.id,
                    allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
                }
                // Add staff role permissions here if needed
                // {
                //     id: 'STAFF_ROLE_ID',
                //     allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory']
                // }
            ]
        });
        
        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Private Channel Created')
            .setDescription(`Your private casino channel has been created: ${channel}`)
            .addFields(
                { name: '🎰 Features Available', value: '• Check balance\n• Play casino games\n• Withdraw funds\n• Get support', inline: false },
                { name: '⏰ Auto-Delete', value: 'Channel will be deleted after 24 hours of inactivity', inline: false }
            )
            .setTimestamp();
        
        await interaction.editReply({ embeds: [successEmbed] });
        
        // Send welcome message in the new channel
        const welcomeEmbed = new EmbedBuilder()
            .setColor('#f7931a')
            .setTitle('🎰 Welcome to Your Private Casino!')
            .setDescription(`Hello ${user}! This is your private casino session.`)
            .addFields(
                { name: '💰 Available Commands', value: '• `/profile` - View your profile\n• `/balance` - Check balance\n• `/givebal` - Transfer balance\n• `/convert-eur-usd` - Currency converter', inline: false },
                { name: '🎮 Coming Soon', value: '• Blackjack\n• Roulette\n• Slots', inline: true },
                { name: '🔧 Support', value: 'Need help? Staff can access this channel.', inline: true }
            )
            .setThumbnail(user.displayAvatarURL())
            .setTimestamp();
        
        await channel.send({ embeds: [welcomeEmbed] });
        
    } catch (error) {
        console.error('❌ Create channel error:', error);
        
        const errorEmbed = new EmbedBuilder()
            .setColor('#ff0000')
            .setTitle('❌ Error')
            .setDescription('Failed to create private channel. Please contact staff.')
            .setTimestamp();
        
        await interaction.editReply({ embeds: [errorEmbed] });
    }
}

// Smart monitoring system
let monitoringInterval = null;

/**
 * Start smart monitoring for active deposits
 */
function startSmartMonitoring() {
    // Don't start if already running
    if (monitoringInterval) return;
    
    console.log('🔍 Démarrage de la surveillance des dépôts...');
    
    // Surveillance automatique toutes les 2 minutes pour respecter les limites API gratuites
    monitoringInterval = setInterval(async () => {
        try {
            const securityManager = require('./utils/securityManager.js');
            const userProfiles = require('./utils/userProfiles.js');
            
            // Get all active deposits
            const activeDeposits = securityManager.getAllActiveDeposits();
            
            if (activeDeposits.length === 0) {
                console.log('ℹ️  Aucun dépôt actif - arrêt de la surveillance');
                stopSmartMonitoring();
                return;
            }
            
            // Check for new deposits
            const detectedDeposits = await ltcWallet.smartDepositCheck(activeDeposits);
            
            // Process detected deposits
            for (const deposit of detectedDeposits) {
                try {
                    // Add deposit to user profile
                    userProfiles.addDeposit(deposit.userId, deposit.amount, deposit.address);
                    
                    // Add to deposited amount for cashout protection
                    securityManager.addDepositedAmount(deposit.userId, deposit.amount);
                    
                    // Mark deposit as completed
                    securityManager.completeDepositRequest(deposit.userId, deposit.address);
                    
                    // Notify user
                    await notifyUserOfDeposit(deposit);
                    
                } catch (error) {
                    console.error('Erreur traitement dépôt:', error);
                }
            }
            
        } catch (error) {
            console.error('Erreur surveillance intelligente:', error);
        }
    }, 120000); // Check every 2 minutes pour respecter les limites BlockCypher gratuit
}

/**
 * Stop smart monitoring
 */
function stopSmartMonitoring() {
    if (monitoringInterval) {
        clearInterval(monitoringInterval);
        monitoringInterval = null;
        console.log('🛑 Surveillance intelligente arrêtée');
    }
}

/**
 * Notify user of detected deposit
 */
async function notifyUserOfDeposit(deposit) {
    try {
        const user = await client.users.fetch(deposit.userId);
        
        if (user) {
            const depositEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Deposit Confirmed!')
                .setDescription('Your Litecoin deposit has been confirmed and added to your balance.')
                .addFields(
                    {
                        name: '💰 Deposit Amount',
                        value: `**${deposit.amount.toFixed(8)} LTC**`,
                        inline: true
                    },
                    {
                        name: '📍 Address',
                        value: `\`${deposit.address}\``,
                        inline: false
                    },
                    {
                        name: '🎰 Ready to Play',
                        value: 'Use `/casino` to start playing!\n**Note:** You must wager 100% of deposited amount before cashout.',
                        inline: false
                    }
                )
                .setThumbnail('https://cryptologos.cc/logos/litecoin-ltc-logo.png')
                .setTimestamp();
            
            // Try to send DM
            try {
                await user.send({ embeds: [depositEmbed] });
                console.log(`💰 Utilisateur ${user.username} notifié du dépôt de ${deposit.amount} LTC`);
            } catch (dmError) {
                console.log(`Impossible d'envoyer un MP à ${user.username}:`, dmError.message);
            }
        }
    } catch (error) {
        console.log('Impossible de notifier l\'utilisateur du dépôt:', error.message);
    }
}

// Export for external use
module.exports = {
    client,
    handleAddBalance,
    handleCreateChannel,
    startSmartMonitoring,
    stopSmartMonitoring
};

// Gestion d'erreurs globales pour éviter les déconnexions
process.on('uncaughtException', (error) => {
    console.error('⚠️ Erreur non gérée capturée:', error);
    console.log('🔄 Le bot continue de fonctionner...');
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('⚠️ Promesse rejetée non gérée:', reason);
    console.log('🔄 Le bot continue de fonctionner...');
});

// Gestion des erreurs Discord
client.on('error', (error) => {
    console.error('⚠️ Erreur client Discord:', error);
    console.log('🔄 Tentative de reconnexion...');
});

client.on('warn', (info) => {
    console.warn('⚠️ Avertissement Discord:', info);
});

client.on('disconnect', () => {
    console.log('⚠️ Bot déconnecté, tentative de reconnexion...');
});

client.on('reconnecting', () => {
    console.log('🔄 Reconnexion en cours...');
});

// Fonction de reconnexion automatique
async function startBotWithRetry() {
    const token = process.env.DISCORD_TOKEN;
    
    if (!token) {
        console.error('❌ DISCORD_TOKEN environment variable is required!');
        process.exit(1);
    }
    
    let retryCount = 0;
    const maxRetries = 5;
    
    while (retryCount < maxRetries) {
        try {
            await client.login(token);
            console.log('✅ Bot connecté avec succès!');
            break;
        } catch (error) {
            retryCount++;
            console.error(`❌ Échec de connexion (tentative ${retryCount}/${maxRetries}):`, error.message);
            
            if (retryCount < maxRetries) {
                const delay = retryCount * 5000; // Délai croissant: 5s, 10s, 15s...
                console.log(`⏳ Nouvelle tentative dans ${delay/1000}s...`);
                await new Promise(resolve => setTimeout(resolve, delay));
            } else {
                console.error('❌ Impossible de se connecter après plusieurs tentatives');
                process.exit(1);
            }
        }
    }
}

// Start the bot if this file is run directly
if (require.main === module) {
    startBotWithRetry();
}